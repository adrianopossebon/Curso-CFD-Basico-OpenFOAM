// Gmsh project created on Wed Mar  8 17:45:53 2023
SetFactory("OpenCASCADE");

cylinderX = 0.2;    // Coordenada x do centro do cilindro. 
cylinderY = 0.2;    // Coordenada y do centro do cilindro.
cylinderZ = -0.4;    // Coordenada z do centro do cilindro.

extrusionLength = 0.8;    // Valor da extrusão na direção z positiva. 

cylinderDiameter = 0.1;    // Diâmetro do cilindro.

splitterThickness = 0.01;    // Splitter thickness.
splitterLength = 0.1;    // Splitter length. 

x = Sqrt(0.25*(cylinderDiameter^2) - 0.25*(splitterThickness^2));

//+
Point(1) = {cylinderX, cylinderY, cylinderZ, 1.0};
Point(2) = {cylinderX + x, cylinderY + splitterThickness/2, cylinderZ, 1.0};
Point(3) = {cylinderX - cylinderDiameter/2, cylinderY, cylinderZ, 1.0};
Point(4) = {cylinderX + x, cylinderY - splitterThickness/2, cylinderZ, 1.0};
Point(5) = {cylinderX + x + splitterLength, cylinderY - splitterThickness/2, cylinderZ, 1.0};
Point(6) = {cylinderX + x + splitterLength, cylinderY + splitterThickness/2, cylinderZ, 1.0};

//+
Circle(1) = {2, 1, 3};
//+
Circle(2) = {4, 1, 3};
//+
Line(3) = {4, 5};
//+
Line(4) = {5, 6};
//+
Line(5) = {6, 2};
//+
Curve Loop(1) = {2, -1, -5, -4, -3};
//+
Plane Surface(1) = {1};
//+
Extrude {0, 0, extrusionLength} {
  Surface{1}; 
}
//+
Physical Volume("internal") = {1};
//+
Physical Surface("cylinderWall") = {1, 7, 4, 3, 6, 2, 5};

//+
Mesh.Algorithm = 6;
Mesh 6;
RefineMesh;
RefineMesh;
RefineMesh;





