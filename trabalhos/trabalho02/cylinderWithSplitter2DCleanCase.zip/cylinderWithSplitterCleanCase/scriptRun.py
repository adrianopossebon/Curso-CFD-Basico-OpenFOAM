import os

os.system('foamCleanCase')

os.system('blockMesh')

os.system('surfaceFeatures')

os.system('snappyHexMesh -overwrite')

os.system('extrudeMesh')

# Para rodar em série.
os.system('foamRun')

